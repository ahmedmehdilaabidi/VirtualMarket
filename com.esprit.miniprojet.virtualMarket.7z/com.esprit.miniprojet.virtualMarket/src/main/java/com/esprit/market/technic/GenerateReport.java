package com.esprit.market.technic;

public class GenerateReport {

}
