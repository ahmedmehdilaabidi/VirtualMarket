package com.esprit.market.serviceImpl;

import java.util.HashSet;

import com.esprit.market.domain.Product;
import com.esprit.market.service.ProductDao;

public class ProductDaoImpl implements ProductDao {

	
	public void addProduct() {
		// TODO Auto-generated method stub
		
	}

	
	public void deleteProduct() {
		// TODO Auto-generated method stub
		
	}

	
	public void updateproduct() {
		// TODO Auto-generated method stub
		
	}

	
	public Product getProductById() {
		// TODO Auto-generated method stub
		return null;
	}

	
	public HashSet<Product> listProduct() {
		// TODO Auto-generated method stub
		return null;
	}

}
